<!DOCTYPE html>
<html>
<head>
<title>CSS Template</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <link rel="stylesheet" href="htmlcss3.css">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: verdana;
}


/* Style the header */
header {
  background-color: white;
  padding: 260px;
  background-image: url(bg_1.jpg);
  background-repeat: no-repeat;
  background-size: 100%,100%;

  
}
section{
	background-color: #F0F0F0;
	padding: 540px;
}

footer {
  background-color:slateblue;
  padding: 50px;
  text-align: center;
  color: white;
  font-family: verdana;
  font-size: 15px;
  
}
.container {
  position: relative;
  font-family: Arial;
}

.text-block {
  position: absolute;
  background-color: #F0F0F0;
  color: black;
  left: 250px;
  top: 10px;
  padding-left: 40px;
  padding-right: 60px;
  padding-top: 20px;
  padding-bottom: 20px;
}
.dot {
  height: 28px;
  width: 32px;
  background-color: #ffdab9;
  border-radius: 50%;
  display: inline-block;
  
}
.dott {
color:tomato;
  height: 25px;
  width: 25px;
  background-color: #ffffe6;
  border-radius: 50%;
  padding-top: 3px;
  display: inline-block;
}

</style>
</head>
<body>
<?php
/*try{

  $ph=new PDO("pgsql:host=localhost;dbname=db","postgres","tiger");
}
catch(PDOException $e)
{
  echo $e->getMessage();

}*/

$conn=pg_connect("host=localhost dbname=db user=postgres password=tiger");

?>

<div class="topnav-right">
  <h3 style="font-family: verdana;float: left;padding-right: 30px;">Jobpply</h3>
    <a class="active" href="#search">Home</a>
    <a href="#about">About</a>
    <a href="#about">Candidates</a>
    <a href="#about">Blog</a>
    <a href="#about">Contact</a>
    <button class="button button1">Post a Job</button>
    <button class="button button2">Want a Job</button>
  
</div>

<header>
<h3 style="float: left;padding-top: 130px;font-family: Arial;font-size: 12px;">Home<span style="padding: 10px;">></span><span style="padding: 20px;font-size: 12px;">JOB POST</span></br><span style="font-family: verdana; font-size: 35px;font-style: bold;">Apply Jobs</span></h3>


</header>


<div class="container">
  
  <div class="text-block">
    
   
   <h4>Recently Added Jobs</h3>
   <h2>Hot Jobs</h2>
   <br>
  
 
  <?php //echo $row['Job_Title'];


  $sql="SELECT * FROM php1";
 $res=pg_query($sql);
 
  while($row=pg_fetch_assoc($res))
  {
    echo '<h3 style="display: inline-block;">';

    echo $row['Job_Title'];
    echo '</h3>';
    ?>
    <button class="buttonnn button7" style="display: inline-block;background-color: slateblue;"><?php echo $row['Job_Type']; ?></button>


<?php
  $files=scandir("Upload");
  for($a=2;$a<count($files);$a++){
?>
<a href="Upload/<?php echo $files[$a] ?>"><?php echo $files[$a] ?></a>
<?php
}
?>

   <div style="text-align:center;display: inline-block;padding-left:560px;">
  <span class="dot" style="padding-top:3px;color:#DC143C;">&#10084;</span>
</div>
  <button class="button button6" style="display: inline-block;">Apply Job</button> 

  <div>
  <i class="fa fa-mortar-board" style="font-size:10px;display:inline-block;"><span style="color: slateblue;padding-left:6px;"><?php echo $row['Company']?></span></i>
   <i class="fa fa-crosshairs" style="font-size:10px;display: inline-block;padding-left:6px;">WESTERN CITY,UK</i>
  </div>
  <hr size="1px;">
    <?php
  }
 
?>
     
<br>
<div style="text-align:center; padding-top: 450px;" >
  <span class="dott"><i class="fa fa-angle-left"></i></span>
  <span class="dott" style="background-color:tomato;color:white;padding-top: 3px;">1</span>
  <span class="dott">2</span>
  <span class="dott">3</span>
  <span class="dott">4</span>
  <span class="dott">5</span>
  <span class="dott"><i class="fa fa-angle-right"></i></span>
</div>

  </div>
</div>

<section>
  
</section>


<div >
<footer>
 <h2 style="text-align: center;">Subscribe to our Newsletter</h2>
 <h4 style="text-align: center;">Far far away,behind the word mountains.far from the countries Vokalia and</br>Consonantia,there live the blind texts.Separated they live in</h4>
 <div style="text-align: center;">
 <input style="height:43px; width:480px;font-size:12px;border-radius: 10px;padding-left: 10px;" type="text" name="uname" placeholder="Enter email address">
 <button style="height: 43px;" class="buttonnn button3">Subscribe</button>
  
</div>
</footer>
</div>
</body>
</html>