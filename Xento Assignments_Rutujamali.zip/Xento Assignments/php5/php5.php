<!DOCTYPE html>
<html>
<head>
<title>CSS Template</title>
 <link rel="stylesheet" href="htmlcss2.css">
 <script>

  function checkButton(){
        if(document.stdreg.b1.checked == true){
            alert("Box1 is checked");
        } else if(document.form1.b2.checked == true){
            alert("Box 2 is checked");
        }
    }
</script>
<style>
*
 {
  box-sizing: border-box;
}

body {
  font-family: verdana;
}

/* Style the header */
header {
  background-color: white;
  padding: 260px;
  background-image: url(bg_1.jpg);
  background-repeat: no-repeat;
  background-size: 100%,100%;

  
}
section{
  background-color: #F0F0F0;
  padding: 480px;
}

footer {
  background-color:slateblue;
  padding: 50px;
  text-align: center;
  color: white;
  font-family: verdana;
  font-size: 15px;
  
}
.container {
  position: relative;
  font-family: verdana;
  font-size: 12px;

}

.text-block {
  border-radius: 8px;
  position: absolute;
  
  right: 700px;
  top: 90px;
  background-color: white;
  color: black;
  padding-left: 40px;
  padding-right: 40px;
  padding-top: 40px;
  padding-bottom: 40px;
}
.text-block1{
  border-radius: 8px;
  position: absolute;
  font-family: verdana;
  font-size: 12px;
  right: 365px;
  top: 620px;
  background-color:white;
  color: black;
  padding-left: 20px;
  padding-right: 105px;
  padding-top: 20px;
  padding-bottom: 20px;
}
.text-block2{
  border-radius: 8px;
  position: absolute;
  font-family: verdana;
  font-size: 12px;
  right: 365px;
  top: 930px;
  background-color: white;
  color: black;
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 20px;
  padding-bottom: 40px;
}


</style>
</head>
<body>


<?php

 $title1Err=$companyErr=$radionbuttonErr=$locationErr=$jobErr="";
 $title1=$company=$radionbutton=$location=$job="";

if($_SERVER["REQUEST_METHOD"]=="POST")
{
  if(empty($_POST["title1"]))
  {
    $title1Err="*Job Title is required";
  }else{
    $title1=test_input($_POST["title1"]);
  }

  if(empty($_POST["company"]))
  {
    $companyErr="*Company name is required";
  }else{
    $company=test_input($_POST["company"]);
  }

  if(empty($_POST["keyskill"])){
    $radionbuttonErr="*Key Skill is required";
  }else{
    $radionbutton=test_input($_POST["keyskill"]);
  }

  if(empty($_POST["location"])){
    $locationErr="*Location is required";
  }else{
    $location=test_input($_POST["location"]);
  }

  if(empty($_POST["job"])){
    $jobErr="*Job Description is required";
  }else{
    $job=test_input($_POST["job"]);
  }
}
function test_input($data)
{
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return $data;
}

?>

<div class="topnav-right">
  <h3 style="font-family: verdana;float: left;padding-right: 30px;">Jobpply</h3>
    <a class="active" href="#search">Home</a>
    <a href="#about">About</a>
    <a href="#about">Candidates</a>
    <a href="#about">Blog</a>
    <a href="#about">Contact</a>
    <button class="button button1">Post a Job</button>
    <button class="button button2">Want a Job</button>
  
</div>

<header>
<h3 style="float: left;padding-top: 130px;font-family: Arial;font-size: 12px;">Home<span style="padding: 10px;">></span><span style="padding: 20px;font-size: 12px;">NEW JOB POST</span></br><span style="font-family: verdana; font-size: 35px;font-style: bold;">Post A Job</span></h3>

</header>

 <div class="container">
  
  <div class="text-block">
    
    <form name="stdreg" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <input style="height: 15px;width: 15px;" type="checkbox" name="chk[]" value="$500"><span style="color: green;">$500</span> For 30 days</br>
      <input style="height: 15px;width: 15px;" type="checkbox" name="chk[]" value="$300"><span style="color: green;">$300</span>/Monthly Recurring</br>
      <h3>Job Title</h3>

      <input style="height:40px; width:450px;font-size:14px;padding-left: 10px; border-radius: 6px;" type="text" name="title1" placeholder="eg.Professional UI/UX Designer" value="<?php if(isset($_POST['title1'])) {echo $_POST['title1'];}?>">

      <span class="error"> <?php echo $title1Err;?></span>

      <h3>Company</h3>
      <input style="height:40px; width:450px;font-size:14px;padding-left: 10px; border-radius: 6px;" type="text" name="company" placeholder="eg.Facebook,Inc." value="<?php if(isset($_POST['company'])) {echo $_POST['company'];}?>"></br>
       <span class="error"> <?php echo $companyErr;?></span>

       <h3>Key Skills</h3>
      <input style="height:40px; width:450px;font-size:14px;padding-left: 10px; border-radius: 6px;" type="text" name="keyskill" placeholder="eg.HTML,CSS,PHP" value="<?php if(isset($_POST['keyskill'])) {echo $_POST['keyskill'];}?>"></br>
      <span class="error"> <?php echo $radionbuttonErr;?></span>
      <br>

      <h2>Location</h2>
      <input style="height:40px; width:450px;font-size:14px;padding-left: 10px; border-radius: 6px;" type="text" name="location" placeholder="Western City,UK" value="<?php if(isset($_POST['loaction'])) {echo $_POST['location'];}?>">
      <span class="error"> <?php echo $locationErr;?></span>
      </br>

      <h2>Job Description</h2>
      <input style="height:130px; width:450px;font-size:14px;padding-left: 10px; border-radius: 6px;" type="text" name="job" value="<?php if(isset($_POST['job'])) {echo $_POST['job'];}?>"></br>
      <span class="error"> <?php echo $jobErr;?></span>
      <br>
       <button class="button button4" type="submit" name="bt" style="background-color: slateblue;border-radius: 5px;">Post</button>
       <?php

 //echo"hello";
if(isset($_POST["bt"]))
  {
    $conn=pg_connect("host=localhost dbname=db user=postgres password=tiger");

    $chkbox=$_POST['chk'];
    $chk="";
   // $radio=$_POST['radionbutton'];
    foreach($chkbox as $chk1)
    {
      $chk .=$chk1.",";
    }

    $query="insert into php1 values ('$chk','$_POST[title1]','$_POST[company]','$_POST[keyskill]')";
    $query=pg_query($query);
    if($query)
    {
      echo "inserted";

    }
    else
    {
      echo "fail";
    }
    pg_close($conn);
}
?>

    </form>
    
  </div>
</div>
<div class="text-block1">
  <h2>Contact Info</h2>
  <h4>Address</h4>
  <h5>203 Fake St. Mountain View,San</br>Francisco,California,USA</h5>
  <h4>Phone</h4>
  <h5 style="color: slateblue;">+1<span style="padding: 7px;"/>232<span style="padding: 7px;"/>3235<span style="padding:7px; "/>324</h5>
  <h4>Email Address</h4>
  <h4 style="color: slateblue;">[email protected]</h4>



  
</div>
<div class="text-block2">
  <h2>More Info</h2>
  <p>Lorem ipsum dolor sit amet,consectular</br>adipisicing edit. lpsa and iure porro mollitia<br>architecto hic consequuntur. Distinctio nisi<br>perferendis dolore,ipsa consectetur</p>
  <button class="button button5">Learn More</button>
  
</div>

<section>
  
</section>


<div >
<footer>
 <h2 style="text-align: center;">Subscribe to our Newsletter</h2>
 <h4 style="text-align: center;">Far far away,behind the word mountains.far from the countries Vokalia and</br>Consonantia,there live the blind texts.Separated they live in</h4>
 <div style="text-align: center;">
 <input style="height:43px; width:480px;font-size:12px;border-radius: 10px;padding-left: 10px;" type="text" name="uname" placeholder="Enter email address">
 <button style="height: 43px;" class="buttonnn button3">Subscribe</button>
  
</div>
</footer>
</div>
</body>
</html>
