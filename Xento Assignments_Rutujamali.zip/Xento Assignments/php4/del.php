 <?php
  $conn=pg_connect("host=localhost dbname=db user=postgres password=tiger");

      if(isset($_GET['id']))
      {
        
      $id1=$_GET['id'];

           // $title1=$row['Job_Title'];
       $remove= "delete from php1 where ".'"php1"."Job_Title"'."='$id1'";
       //echo $remove;
        //$remove=pg_delete($conn, 'php1', $id1);
        $run=pg_query($conn,$remove);
        
        if($run)
        {
          include('php4.php');
        }
        else
        {
          echo "Not deleted";
        }
      }
    ?>