<?php
class CPostJob
{
	function browser(){

try{

	$ph=new PDO("pgsql:host=localhost;dbname=db","postgres","tiger");
	$sql="SELECT * FROM php1";

	foreach($ph->query($sql) as $row)
	{
		print "</br>";
		print 'Salary-:'.$row['Salary'].'<br/>'.'Job_Title:-'.$row['Job_Title'].'<br/>'.'Company:-'.$row['Company'].'<br/>'.'Job_Type:-'.$row['Job_Type'];
	}

}catch(PDOException $e)
{
	echo $e->getMessage();

}
}

}

$cp = new CPostJob();
$cp->browser();
?>